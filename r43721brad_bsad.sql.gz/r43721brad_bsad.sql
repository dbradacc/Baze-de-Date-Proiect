/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.19-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: r43721brad_bsad
-- ------------------------------------------------------
-- Server version	10.6.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Audit_Log`
--

DROP TABLE IF EXISTS `Audit_Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Audit_Log` (
  `ID_Audit` int(11) NOT NULL AUTO_INCREMENT,
  `ID_User` int(11) NOT NULL,
  `IP` varchar(45) NOT NULL,
  `Actiune` varchar(20) NOT NULL,
  `Entitate` varchar(30) NOT NULL,
  `ID_Ent` int(11) DEFAULT NULL,
  `Info` text DEFAULT NULL,
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID_Audit`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Audit_Log`
--

LOCK TABLES `Audit_Log` WRITE;
/*!40000 ALTER TABLE `Audit_Log` DISABLE KEYS */;
INSERT INTO `Audit_Log` (`ID_Audit`, `ID_User`, `IP`, `Actiune`, `Entitate`, `ID_Ent`, `Info`, `Created_at`) VALUES (1,1,'','create','Studenti',NULL,'{\"nume\":\"Petre\",\"prenume\":\"Cosmin\",\"email\":\"petre@cosmin.ro\",\"telefon\":\"0785635212\",\"an_studiu\":\"2\"}','2025-05-05 18:57:19'),(2,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','delete','Studenti',7,NULL,'2025-05-05 19:02:21'),(3,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','delete','Studenti',3,NULL,'2025-05-05 19:04:15'),(4,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Studenti',NULL,'{\"nume\":\"test\",\"prenume\":\"test\",\"email\":\"test@test.com\",\"telefon\":\"0728333222\",\"an_studiu\":\"2\"}','2025-05-05 19:06:50'),(5,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','delete','Studenti',8,NULL,'2025-05-05 19:12:32'),(6,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Studenti',NULL,'{\"nume\":\"ADMINS\",\"prenume\":\"Test2\",\"email\":\"CAS@MDS.CPM\",\"telefon\":\"0788822222\",\"an_studiu\":\"2\"}','2025-05-05 19:14:07'),(7,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','delete','Studenti',10,'{\"ID_Student\":10,\"Nume\":\"ADMINS\",\"Prenume\":\"Test2\",\"Email\":\"CAS@MDS.CPM\",\"Telefon\":\"0788822222\",\"An_Studiu\":2}','2025-05-05 19:16:21'),(8,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Inscrieri',NULL,'{\"id_student\":\"4\",\"id_curs\":\"2\",\"nota\":\"10\"}','2025-05-05 19:21:31'),(9,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Inscrieri',NULL,'{\"id_student\":\"6\",\"id_curs\":\"2\",\"nota\":\"9\"}','2025-05-05 19:24:50'),(10,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Inscrieri',4,'{\"id_student\":\"4\",\"id_curs\":\"2\",\"nota\":\"8\"}','2025-05-05 19:30:01'),(11,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Utilizatori',NULL,'{\"username\":\"andreea\",\"password\":\"7Qtx6wr938\",\"role\":\"admin\"}','2025-05-05 19:30:24'),(12,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Utilizatori',1,'{\"username\":\"admin\",\"password\":\".7Qtx6wr9389tym4\",\"role\":\"admin\"}','2025-05-05 19:30:44'),(13,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Utilizatori',2,'{\"username\":\"andreea\",\"password\":\"7Qtx6wr938\",\"role\":\"admin\"}','2025-05-05 19:31:23'),(14,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Utilizatori',1,'{\"username\":\"dbradac\",\"password\":\".7Qtx6wr938\",\"role\":\"admin\"}','2025-05-05 19:32:32'),(15,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Utilizatori',2,'{\"username\":\"anegru\",\"password\":\"7Qtx6wr938\",\"role\":\"admin\"}','2025-05-05 19:32:59'),(16,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Utilizatori',NULL,'{\"username\":\"gsimona\",\"password\":\"simonagrama2003\",\"role\":\"admin\"}','2025-05-05 19:37:00'),(17,3,'2a02:2f0e:d001:db00:908b:8ee8:8997:27c9','update','Studenti',6,'{\"nume\":\"Grama\",\"prenume\":\"Simona\",\"email\":\"gramasimona@gmail.com\",\"telefon\":\"0786888856\",\"an_studiu\":\"3\"}','2025-05-05 19:40:31'),(18,3,'2a02:2f0e:d001:db00:908b:8ee8:8997:27c9','create','Studenti',NULL,'{\"nume\":\"Popescu\",\"prenume\":\"Andrei\",\"email\":\"andrei.popescu@yahoo.com\",\"telefon\":\"0732498348\",\"an_studiu\":\"1\"}','2025-05-05 19:55:44'),(19,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Studenti',NULL,'{\"nume\":\"Negru \",\"prenume\":\"Andreea\",\"email\":\"negruandreea@icloud.com\",\"telefon\":\"0799531472\",\"an_studiu\":\"3\"}','2025-05-05 20:16:54'),(20,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Inscrieri',NULL,'{\"id_student\":\"12\",\"id_curs\":\"5\",\"nota\":\"7.50\"}','2025-05-05 20:18:41'),(21,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Prezente',5,'{\"data\":\"2025-05-05\",\"semester\":\"1\",\"id_student\":\"12\",\"id_curs\":\"2\",\"status\":\"prezent\"}','2025-05-05 20:30:57'),(22,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Studenti',12,'{\"nume\":\"Negru \",\"prenume\":\"Andreea\",\"email\":\"negruandreea@icloud.co\",\"telefon\":\"0799531472\",\"an_studiu\":\"3\"}','2025-05-05 20:31:14'),(23,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Studenti',12,'{\"nume\":\"Negru \",\"prenume\":\"Andreea\",\"email\":\"negruandreea@icloud.com\",\"telefon\":\"0799531472\",\"an_studiu\":\"3\"}','2025-05-05 20:31:20'),(24,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Studenti',NULL,'{\"nume\":\"test\",\"prenume\":\"test\",\"email\":\"test@test.com\",\"telefon\":\"1234567890\",\"an_studiu\":\"2\"}','2025-05-05 20:31:47'),(25,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','delete','Studenti',13,'{\"ID_Student\":13,\"Nume\":\"test\",\"Prenume\":\"test\",\"Email\":\"test@test.com\",\"Telefon\":\"1234567890\",\"An_Studiu\":2}','2025-05-05 20:31:51'),(26,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Cursuri',15,'{\"denumire\":\"Bazele sistemelor de achizitii de dat\",\"profesor\":\"Cotfas Petru Adrian\",\"nr_credite\":\"3\",\"semester\":\"1\"}','2025-05-05 20:32:03'),(27,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Cursuri',15,'{\"denumire\":\"Bazele sistemelor de achizitii de date\",\"profesor\":\"Cotfas Petru Adrian\",\"nr_credite\":\"3\",\"semester\":\"1\"}','2025-05-05 20:32:08'),(28,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Inscrieri',NULL,'{\"id_student\":\"11\",\"id_curs\":\"14\",\"nota\":\"2\"}','2025-05-05 20:32:17'),(29,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','delete','Prezente',5,'{\"ID_Prezenta\":5,\"Data\":\"2025-05-05\",\"ID_Student\":12,\"ID_Curs\":2,\"Status\":\"prezent\",\"Semester\":1}','2025-05-05 20:32:39'),(30,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Prezente',NULL,'{\"data\":\"2025-05-05\",\"semester\":\"2\",\"id_student\":\"12\",\"id_curs\":\"2\",\"status\":\"absent\"}','2025-05-05 20:32:50'),(31,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Cursuri',3,'{\"denumire\":\"Teoria transmisiunii informatiei\",\"profesor\":\"Miron Miha\",\"nr_credite\":\"5\",\"semester\":\"2\"}','2025-05-05 20:34:54'),(32,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','update','Cursuri',3,'{\"denumire\":\"Teoria transmisiunii informatiei\",\"profesor\":\"Miron Mihai\",\"nr_credite\":\"5\",\"semester\":\"2\"}','2025-05-05 20:35:00'),(33,2,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','logout','Auth',NULL,NULL,'2025-05-05 20:35:01'),(34,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','login','Auth',NULL,NULL,'2025-05-05 20:35:09'),(35,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Prezente',NULL,'{\"data\":\"2025-02-05\",\"semester\":\"1\",\"id_student\":\"12\",\"id_curs\":\"9\",\"status\":\"absent\"}','2025-05-05 20:36:26'),(36,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','logout','Auth',NULL,NULL,'2025-05-05 20:45:12'),(37,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','login','Auth',NULL,NULL,'2025-05-05 20:45:18'),(38,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Inscrieri',NULL,'{\"id_student\":\"11\",\"id_curs\":\"13\",\"nota\":\"3\"}','2025-05-05 20:45:56'),(39,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Prezente',NULL,'{\"data\":\"2025-05-05\",\"semester\":\"2\",\"id_student\":\"4\",\"id_curs\":\"11\",\"status\":\"absent\"}','2025-05-05 20:47:21'),(40,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','create','Prezente',NULL,'{\"data\":\"2025-05-05\",\"semester\":\"2\",\"id_student\":\"4\",\"id_curs\":\"11\",\"status\":\"absent\"}','2025-05-05 20:47:43'),(41,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','logout','Auth',NULL,NULL,'2025-05-05 21:17:00'),(42,1,'2a02:2f01:f602:8b00:95f1:aefd:8cae:9aa7','login','Auth',NULL,NULL,'2025-05-06 06:56:36'),(43,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','login','Auth',NULL,NULL,'2025-05-06 07:08:19'),(44,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','delete','Inscrieri',12,'{\"ID_Student\":12,\"ID_Curs\":5,\"Nota_Finala\":\"7.5\"}','2025-05-06 07:20:41'),(45,3,'2a02:2f0e:d001:db00:908b:8ee8:8997:27c9','login','Auth',NULL,NULL,'2025-05-06 08:36:37'),(46,3,'2a02:2f0e:d001:db00:908b:8ee8:8997:27c9','create','Prezente',NULL,'{\"data\":\"2025-05-06\",\"semester\":\"1\",\"id_student\":\"6\",\"id_curs\":\"5\",\"status\":\"prezent\"}','2025-05-06 08:37:20'),(47,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','login','Auth',NULL,NULL,'2025-05-06 08:57:07'),(48,1,'2a02:2f01:f602:8b00:61a1:917b:fc67:1b4e','logout','Auth',NULL,NULL,'2025-05-06 08:57:57'),(49,1,'34.103.242.69','login','Auth',NULL,NULL,'2025-05-06 09:46:25'),(50,1,'34.103.242.69','login','Auth',NULL,NULL,'2025-05-06 11:22:03'),(51,3,'2a02:2f0e:d001:db00:908b:8ee8:8997:27c9','login','Auth',NULL,NULL,'2025-05-06 12:00:51'),(52,3,'2a02:2f0e:d001:db00:908b:8ee8:8997:27c9','create','Studenti',NULL,'{\"nume\":\"Ghita\",\"prenume\":\"Miruna\",\"email\":\"mirunaghita10@gmail.com\",\"telefon\":\"0732614813\",\"an_studiu\":\"3\"}','2025-05-06 12:01:50'),(53,3,'86.124.191.42','login','Auth',NULL,NULL,'2025-05-06 15:41:20'),(54,3,'86.124.191.42','create','Inscrieri',NULL,'{\"id_student\":\"6\",\"id_curs\":\"12\",\"nota\":\"4\"}','2025-05-06 15:41:49'),(55,3,'86.124.191.42','create','Prezente',NULL,'{\"data\":\"2025-05-06\",\"semester\":\"2\",\"id_student\":\"16\",\"id_curs\":\"6\",\"status\":\"absent\"}','2025-05-06 15:50:54'),(56,3,'86.124.191.42','create','Prezente',NULL,'{\"data\":\"2025-05-06\",\"semester\":\"2\",\"id_student\":\"11\",\"id_curs\":\"3\",\"status\":\"prezent\"}','2025-05-06 15:51:14'),(57,1,'2a02:2f01:f602:8b00:4d6:1ce2:107d:ebb1','login','Auth',NULL,NULL,'2025-05-06 21:39:01'),(58,1,'193.254.231.207','login','Auth',NULL,NULL,'2025-05-07 09:08:17'),(59,1,'193.254.231.207','create','Prezente',NULL,'{\"data\":\"2025-05-07\",\"semester\":\"2\",\"id_student\":\"12\",\"id_curs\":\"2\",\"status\":\"prezent\"}','2025-05-07 09:08:46'),(60,2,'193.254.231.207','login','Auth',NULL,NULL,'2025-05-07 09:10:27'),(61,1,'193.254.231.207','create','Studenti',NULL,'{\"nume\":\"Calu\",\"prenume\":\"Marian\",\"email\":\"marian@calu.ro\",\"telefon\":\"0789734221\",\"an_studiu\":\"2\"}','2025-05-07 09:10:27'),(62,1,'193.254.231.207','create','Studenti',NULL,'{\"nume\":\"Iapa\",\"prenume\":\"Miruna\",\"email\":\"miruna@iapa.ro\",\"telefon\":\"0798723122\",\"an_studiu\":\"1\"}','2025-05-07 09:10:53'),(63,1,'193.254.231.207','create','Inscrieri',NULL,'{\"id_student\":\"18\",\"id_curs\":\"15\",\"nota\":\"8\"}','2025-05-07 09:11:04'),(64,1,'193.254.231.207','create','Inscrieri',NULL,'{\"id_student\":\"17\",\"id_curs\":\"14\",\"nota\":\"6\"}','2025-05-07 09:11:14'),(65,1,'193.254.231.207','create','Inscrieri',NULL,'{\"id_student\":\"18\",\"id_curs\":\"2\",\"nota\":\"4\"}','2025-05-07 09:11:23'),(66,2,'193.254.231.207','create','Studenti',NULL,'{\"nume\":\"Negru\",\"prenume\":\"Larisa\",\"email\":\"larisanegru04@gmail.com\",\"telefon\":\"0734927231\",\"an_studiu\":\"4\"}','2025-05-07 09:11:30'),(67,1,'193.254.231.207','create','Prezente',NULL,'{\"data\":\"2025-05-07\",\"semester\":\"2\",\"id_student\":\"18\",\"id_curs\":\"12\",\"status\":\"prezent\"}','2025-05-07 09:11:55'),(68,1,'193.254.231.207','create','Prezente',NULL,'{\"data\":\"2025-05-07\",\"semester\":\"1\",\"id_student\":\"18\",\"id_curs\":\"6\",\"status\":\"absent\"}','2025-05-07 09:12:07'),(69,2,'193.254.231.207','create','Inscrieri',NULL,'{\"id_student\":\"19\",\"id_curs\":\"11\",\"nota\":\"6.50\"}','2025-05-07 09:12:43'),(70,1,'34.103.242.69','logout','Auth',NULL,NULL,'2025-05-07 09:13:18'),(71,2,'193.254.231.207','create','Prezente',NULL,'{\"data\":\"2025-05-04\",\"semester\":\"1\",\"id_student\":\"19\",\"id_curs\":\"14\",\"status\":\"absent\"}','2025-05-07 09:13:33'),(72,2,'193.254.231.207','create','Prezente',NULL,'{\"data\":\"2025-05-07\",\"semester\":\"2\",\"id_student\":\"19\",\"id_curs\":\"7\",\"status\":\"prezent\"}','2025-05-07 09:14:06'),(73,2,'193.254.231.207','create','Studenti',NULL,'{\"nume\":\"Dimeny\",\"prenume\":\"Adrian\",\"email\":\"adriandimeny20@gmail.com\",\"telefon\":\"0724365221\",\"an_studiu\":\"3\"}','2025-05-07 09:15:32'),(74,2,'193.254.231.207','create','Inscrieri',NULL,'{\"id_student\":\"12\",\"id_curs\":\"14\",\"nota\":\"5.5\"}','2025-05-07 09:16:40'),(75,2,'193.254.231.207','create','Inscrieri',NULL,'{\"id_student\":\"20\",\"id_curs\":\"10\",\"nota\":\"7\"}','2025-05-07 09:17:10'),(76,2,'193.254.231.207','create','Prezente',NULL,'{\"data\":\"2025-05-07\",\"semester\":\"2\",\"id_student\":\"20\",\"id_curs\":\"10\",\"status\":\"prezent\"}','2025-05-07 09:17:42'),(77,2,'193.254.231.207','create','Studenti',NULL,'{\"nume\":\"Militaru\",\"prenume\":\"Rares\",\"email\":\"rareshmili2003@gmail.com\",\"telefon\":\"0722981754\",\"an_studiu\":\"4\"}','2025-05-07 09:18:25'),(78,2,'193.254.231.207','create','Inscrieri',NULL,'{\"id_student\":\"21\",\"id_curs\":\"9\",\"nota\":\"6\"}','2025-05-07 09:20:11'),(79,2,'193.254.231.207','create','Prezente',NULL,'{\"data\":\"2025-05-07\",\"semester\":\"1\",\"id_student\":\"21\",\"id_curs\":\"9\",\"status\":\"absent\"}','2025-05-07 09:21:10'),(80,2,'193.254.231.207','update','Prezente',19,'{\"data\":\"2025-05-07\",\"semester\":\"1\",\"id_student\":\"21\",\"id_curs\":\"9\",\"status\":\"prezent\"}','2025-05-07 09:21:30'),(81,2,'193.254.231.207','create','Studenti',NULL,'{\"nume\":\"Deleanu\",\"prenume\":\"Andrei\",\"email\":\"deli2002@gmail.com\",\"telefon\":\"0783241985\",\"an_studiu\":\"4\"}','2025-05-07 09:24:25'),(82,3,'2a02:2f0e:d001:db00:850e:dac8:cc43:89e6','login','Auth',NULL,NULL,'2025-05-07 09:45:12'),(83,3,'2a02:2f0e:d001:db00:850e:dac8:cc43:89e6','create','Studenti',NULL,'{\"nume\":\"Costache\",\"prenume\":\"Laurentiu\",\"email\":\"laurcostache11@gmail.com\",\"telefon\":\"0712543215\",\"an_studiu\":\"3\"}','2025-05-07 09:47:37'),(84,3,'2a02:2f0e:d001:db00:850e:dac8:cc43:89e6','create','Studenti',NULL,'{\"nume\":\"Niculescu\",\"prenume\":\"Alina Elena\",\"email\":\"alinana2002@yahoo.com\",\"telefon\":\"0732561786\",\"an_studiu\":\"2\"}','2025-05-07 09:49:01'),(85,3,'2a02:2f0e:d001:db00:850e:dac8:cc43:89e6','create','Inscrieri',NULL,'{\"id_student\":\"23\",\"id_curs\":\"10\",\"nota\":\"6\"}','2025-05-07 09:49:59'),(86,3,'2a02:2f0e:d001:db00:850e:dac8:cc43:89e6','create','Inscrieri',NULL,'{\"id_student\":\"24\",\"id_curs\":\"3\",\"nota\":\"7\"}','2025-05-07 09:50:21'),(87,3,'2a02:2f0e:d001:db00:850e:dac8:cc43:89e6','create','Inscrieri',NULL,'{\"id_student\":\"23\",\"id_curs\":\"9\",\"nota\":\"10\"}','2025-05-07 09:50:38'),(88,3,'2a02:2f0e:d001:db00:850e:dac8:cc43:89e6','create','Inscrieri',NULL,'{\"id_student\":\"24\",\"id_curs\":\"15\",\"nota\":\"4.5\"}','2025-05-07 09:51:01'),(89,2,'193.254.231.207','login','Auth',NULL,NULL,'2025-05-07 10:04:49'),(90,3,'2a02:2f0e:d001:db00:850e:dac8:cc43:89e6','login','Auth',NULL,NULL,'2025-05-07 21:36:18'),(91,1,'34.103.242.69','login','Auth',NULL,NULL,'2025-05-07 23:57:27'),(92,1,'34.103.242.69','create','Utilizatori',NULL,'{\"username\":\"profesor\",\"password\":\"7qtx6wr938\",\"role\":\"profesor\"}','2025-05-07 23:58:45'),(93,1,'34.103.242.69','logout','Auth',NULL,NULL,'2025-05-07 23:58:48'),(94,4,'34.103.242.69','login','Auth',NULL,NULL,'2025-05-07 23:58:50'),(95,4,'34.103.242.69','logout','Auth',NULL,NULL,'2025-05-07 23:59:04'),(96,1,'34.103.242.69','login','Auth',NULL,NULL,'2025-05-07 23:59:17'),(97,1,'34.103.242.69','create','Utilizatori',NULL,'{\"username\":\"secretar\",\"password\":\"7qtx6wr938\",\"role\":\"secretar\"}','2025-05-07 23:59:36'),(98,1,'34.103.242.69','logout','Auth',NULL,NULL,'2025-05-07 23:59:39'),(99,5,'34.103.242.69','login','Auth',NULL,NULL,'2025-05-07 23:59:41'),(100,5,'34.103.242.69','logout','Auth',NULL,NULL,'2025-05-08 00:00:18'),(101,1,'34.103.242.69','login','Auth',NULL,NULL,'2025-05-08 00:00:26'),(102,3,'193.254.231.207','login','Auth',NULL,NULL,'2025-05-08 11:23:45'),(103,3,'193.254.231.207','update','Cursuri',8,'{\"denumire\":\"Practica de specialitate\",\"profesor\":\"Popescu Vlad\",\"nr_credite\":\"4\",\"semester\":\"2\"}','2025-05-08 11:24:24'),(104,1,'34.103.242.69','login','Auth',NULL,NULL,'2025-05-08 20:41:37'),(105,1,'34.103.242.69','create','Inscrieri',NULL,'{\"id_student\":\"22\",\"id_curs\":\"11\",\"nota\":\"5\"}','2025-05-08 20:42:31'),(106,1,'34.103.242.69','login','Auth',NULL,NULL,'2025-05-09 10:33:40'),(107,3,'2a02:2f0e:d001:db00:dd95:3401:899b:4bb7','login','Auth',NULL,NULL,'2025-05-11 13:07:16');
/*!40000 ALTER TABLE `Audit_Log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cursuri`
--

DROP TABLE IF EXISTS `Cursuri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cursuri` (
  `ID_Curs` int(11) NOT NULL AUTO_INCREMENT,
  `Denumire` varchar(100) NOT NULL,
  `Profesor_Titular` varchar(100) NOT NULL,
  `Nr_Credite` tinyint(4) NOT NULL CHECK (`Nr_Credite` > 0),
  `Semester` tinyint(1) NOT NULL COMMENT '1 = semestrul 1, 2 = semestrul 2',
  PRIMARY KEY (`ID_Curs`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cursuri`
--

LOCK TABLES `Cursuri` WRITE;
/*!40000 ALTER TABLE `Cursuri` DISABLE KEYS */;
INSERT INTO `Cursuri` (`ID_Curs`, `Denumire`, `Profesor_Titular`, `Nr_Credite`, `Semester`) VALUES (2,'Baze de Date','Oprisescu Serban',4,2),(3,'Teoria transmisiunii informatiei','Miron Mihai',5,2),(4,'Telefonie si sisteme de comutatie a fluxurilor media','Curpen Dan Mihail',4,2),(5,'Modularea si demodularea semnalelor','Croitoru Otilia',5,2),(6,'Prelucrarea digitala a semnalelor','Miron Mihai',4,2),(7,'Sisteme de operare','Kertesz Csaba Zoltan',4,2),(8,'Practica de specialitate','Popescu Vlad',4,2),(9,'Software pentru telecomunicatii','Modran Horia Alexandru',4,1),(10,'Microcontrolere','Romanca Mihai',5,1),(11,'Arhitecturi de retea si internet','Robu Dan Nicolae ',5,1),(12,'Antene, linii si propagare','Miron Mihai',5,1),(13,'Comutatia circuitelor, a pachetelor si serviciilor','Alexandru Marian',5,1),(14,'Inginerie audio','Stanca Aurel Cornel si Ungureanu Daniel Constantin',3,1),(15,'Bazele sistemelor de achizitii de date','Cotfas Petru Adrian',3,1);
/*!40000 ALTER TABLE `Cursuri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Inscrieri`
--

DROP TABLE IF EXISTS `Inscrieri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Inscrieri` (
  `ID_Student` int(11) NOT NULL,
  `ID_Curs` int(11) NOT NULL,
  `Nota_Finala` decimal(3,1) NOT NULL CHECK (`Nota_Finala` between 1 and 10),
  PRIMARY KEY (`ID_Student`,`ID_Curs`),
  KEY `ID_Curs` (`ID_Curs`),
  CONSTRAINT `Inscrieri_ibfk_1` FOREIGN KEY (`ID_Student`) REFERENCES `Studenti` (`ID_Student`) ON DELETE CASCADE,
  CONSTRAINT `Inscrieri_ibfk_2` FOREIGN KEY (`ID_Curs`) REFERENCES `Cursuri` (`ID_Curs`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Inscrieri`
--

LOCK TABLES `Inscrieri` WRITE;
/*!40000 ALTER TABLE `Inscrieri` DISABLE KEYS */;
INSERT INTO `Inscrieri` (`ID_Student`, `ID_Curs`, `Nota_Finala`) VALUES (4,2,8.0),(6,2,9.0),(6,12,4.0),(11,13,3.0),(11,14,2.0),(12,14,5.5),(17,14,6.0),(18,2,4.0),(18,15,8.0),(19,11,6.5),(20,10,7.0),(21,9,6.0),(22,11,5.0),(23,9,10.0),(23,10,6.0),(24,3,7.0),(24,15,4.5);
/*!40000 ALTER TABLE `Inscrieri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Prezente`
--

DROP TABLE IF EXISTS `Prezente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Prezente` (
  `ID_Prezenta` int(11) NOT NULL AUTO_INCREMENT,
  `Data` date NOT NULL,
  `ID_Student` int(11) NOT NULL,
  `ID_Curs` int(11) NOT NULL,
  `Status` enum('prezent','absent') NOT NULL,
  `Semester` tinyint(1) NOT NULL COMMENT '1 = semestrul 1, 2 = semestrul 2',
  PRIMARY KEY (`ID_Prezenta`),
  KEY `fk_prez_student` (`ID_Student`),
  KEY `fk_prez_curs` (`ID_Curs`),
  CONSTRAINT `fk_prez_curs` FOREIGN KEY (`ID_Curs`) REFERENCES `Cursuri` (`ID_Curs`) ON DELETE CASCADE,
  CONSTRAINT `fk_prez_student` FOREIGN KEY (`ID_Student`) REFERENCES `Studenti` (`ID_Student`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Prezente`
--

LOCK TABLES `Prezente` WRITE;
/*!40000 ALTER TABLE `Prezente` DISABLE KEYS */;
INSERT INTO `Prezente` (`ID_Prezenta`, `Data`, `ID_Student`, `ID_Curs`, `Status`, `Semester`) VALUES (3,'2025-05-05',6,2,'prezent',2),(4,'2025-05-05',4,2,'prezent',2),(6,'2025-05-05',12,2,'absent',2),(7,'2025-02-05',12,9,'absent',1),(8,'2025-05-05',4,11,'absent',2),(9,'2025-05-05',4,11,'absent',2),(10,'2025-05-06',6,5,'prezent',1),(11,'2025-05-06',16,6,'absent',2),(12,'2025-05-06',11,3,'prezent',2),(13,'2025-05-07',12,2,'prezent',2),(14,'2025-05-07',18,12,'prezent',2),(15,'2025-05-07',18,6,'absent',1),(16,'2025-05-04',19,14,'absent',1),(17,'2025-05-07',19,7,'prezent',2),(18,'2025-05-07',20,10,'prezent',2),(19,'2025-05-07',21,9,'prezent',1);
/*!40000 ALTER TABLE `Prezente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Studenti`
--

DROP TABLE IF EXISTS `Studenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Studenti` (
  `ID_Student` int(11) NOT NULL AUTO_INCREMENT,
  `Nume` varchar(50) NOT NULL,
  `Prenume` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Telefon` varchar(20) NOT NULL COMMENT 'număr de telefon',
  `An_Studiu` tinyint(4) NOT NULL CHECK (`An_Studiu` between 1 and 6),
  PRIMARY KEY (`ID_Student`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Studenti`
--

LOCK TABLES `Studenti` WRITE;
/*!40000 ALTER TABLE `Studenti` DISABLE KEYS */;
INSERT INTO `Studenti` (`ID_Student`, `Nume`, `Prenume`, `Email`, `Telefon`, `An_Studiu`) VALUES (4,'Bradac','Catalin Daniel','daniel@bradac.ro','0759656923',3),(6,'Grama','Simona','gramasimona@gmail.com','0786888856',3),(11,'Popescu','Andrei','andrei.popescu@yahoo.com','0732498348',1),(12,'Negru ','Andreea','negruandreea@icloud.com','0799531472',3),(16,'Ghita','Miruna','mirunaghita10@gmail.com','0732614813',3),(17,'Calu','Marian','marian@calu.ro','0789734221',2),(18,'Iapa','Miruna','miruna@iapa.ro','0798723122',1),(19,'Negru','Larisa','larisanegru04@gmail.com','0734927231',4),(20,'Dimeny','Adrian','adriandimeny20@gmail.com','0724365221',3),(21,'Militaru','Rares','rareshmili2003@gmail.com','0722981754',4),(22,'Deleanu','Andrei','deli2002@gmail.com','0783241985',4),(23,'Costache','Laurentiu','laurcostache11@gmail.com','0712543215',3),(24,'Niculescu','Alina Elena','alinana2002@yahoo.com','0732561786',2);
/*!40000 ALTER TABLE `Studenti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Utilizatori`
--

DROP TABLE IF EXISTS `Utilizatori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Utilizatori` (
  `ID_User` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `Role` enum('admin','secretar','profesor') NOT NULL DEFAULT 'profesor',
  PRIMARY KEY (`ID_User`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Utilizatori`
--

LOCK TABLES `Utilizatori` WRITE;
/*!40000 ALTER TABLE `Utilizatori` DISABLE KEYS */;
INSERT INTO `Utilizatori` (`ID_User`, `username`, `password_hash`, `Role`) VALUES (1,'dbradac','$2y$12$/VXF65ZkNh5fmy.CcL4UJeGommEUDkfH03QusL3tpktZce4gWBiWS','admin'),(2,'anegru','$2y$12$4uaKXkaRUq8BgA6QX0DNNeifqoIHAk/fiPXSqUAj2clBLHUdCXfwK','admin'),(3,'gsimona','$2y$12$3ELp/RpGRVYMHXFs3I84jum.lfg3S66FMboZNOAi1J1kmix3Wf5JK','admin'),(4,'profesor','$2y$12$EK.ow1IwYzHxRSbdeZJgaOnia7MKnErF993ZLH43g.xn4LCJvcVru','profesor'),(5,'secretar','$2y$12$FnqH9skiRvvn2zGcU9YRLuz.XZQNG5CSmcmHwhap64Ki56u.hYWuu','secretar');
/*!40000 ALTER TABLE `Utilizatori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'r43721brad_bsad'
--

--
-- Dumping routines for database 'r43721brad_bsad'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-11 16:24:37
